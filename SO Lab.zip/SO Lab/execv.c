#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void bubbleSort(int arr[], int n) {
    int temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    pid_t pid = fork();

    if (pid == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {  // Parent process
        printf("Parent process (PID %d) is sorting the array using bubble sort...\n", getpid());
        bubbleSort(arr, n);

        // Wait for the child process to complete
        wait(NULL);

        // Display the sorted array in the parent process
        printf("Sorted array in parent process: ");
        for (int i = 0; i < n; i++) {
            printf("%d ", arr[i]);
        }
        printf("\n");
    } else {  // Child process
        // Convert the sorted array to strings
        char *args[n + 3];  // 3 extra slots: program name, NULL terminator, and an indicator for exec
        args[0] = "./display_reverse";  // Assuming the executable is named 'display_reverse'
        for (int i = 0; i < n; i++) {
            args[i + 1] = malloc(12);  // Assuming integers can be represented in 12 characters
            sprintf(args[i + 1], "%d", arr[i]);
        }
        args[n + 1] = NULL;  // NULL terminator

        // Execute the child process to display the array in reverse order
        execv(args[0], args);

        // If execve fails, print an error message and exit
        perror("Execve failed");
        exit(EXIT_FAILURE);
    }

    return 0;
}


//2nd file
#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("Array in reverse order: ");
    for (int i = argc - 1; i > 0; i--) {
        printf("%s ", argv[i]);
    }
    printf("\n");

    return 0;
}

