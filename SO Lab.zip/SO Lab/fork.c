#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void bubbleSort(int arr[], int n) {
    int temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void selectionSort(int arr[], int n) {
    int i, j, min_idx, temp;
    for (i = 0; i < n - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        temp = arr[min_idx];
        arr[min_idx] = arr[i];
        arr[i] = temp;
    }
}

int main() {
    int n;

    printf("Enter the number of integers to be sorted: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    pid_t pid = fork();

    if (pid == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {  // Parent process
        printf("Parent process (PID %d) is sorting the array using bubble sort...\n", getpid());
        bubbleSort(arr, n);

        // Introduce a delay to demonstrate the orphan state
        sleep(5);
        printf("Parent process (PID %d) becomes an orphan\n", getpid());

        // The parent process will exit, and the child will become an orphan
        exit(EXIT_SUCCESS);
    } else {  // Child process
        printf("Child process (PID %d) is sorting the array \n", getpid());
        selectionSort(arr, n);

        // Introduce a delay to demonstrate the zombie state
        printf("Child process (PID %d) becomes a zombie\n", getpid());
        sleep(2);

        printf("Sorted array in child process: ");
        for (int i = 0; i < n; i++) {
            printf("%d ", arr[i]);
        }
        printf("\n");

        exit(EXIT_SUCCESS);
    }

    return 0;
}
